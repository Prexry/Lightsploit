# DST Server Control Panel

A professional, fully-functional web-based control panel for Don't Starve Together dedicated servers.

## Features

### Real Backend Integration
- Python Flask REST API
- Live server monitoring via screen sessions
- Real log parsing and player detection
- Actual command execution to game servers
- File reading/writing for configuration

### Server Control
- Start/Stop/Restart servers
- Execute Lua commands
- Save/Rollback world
- Real-time status monitoring

### Player Management
- Live player list
- Kick/Ban/Admin privileges
- Heal/God mode/Teleport
- Kill/Resurrect players

### Configuration Editor
- Edit all config files directly
- cluster.ini
- server.ini (Master/Caves)
- worldgenoverride.lua
- modoverrides.lua
- Automatic backup before saving

### Mod Manager
- Toggle mods on/off
- Add new mods by Workshop ID
- Updates modoverrides.lua for both shards

### Backup System
- Create manual backups
- List all backups with size/date
- Restore from backup
- Automatic pre-restore safety checks

### Log Viewer
- Master/Caves server logs
- Chat logs
- Real-time log streaming
- Last 500 lines displayed

## Installation

### On Your Debian Docker Container

```bash
# Install Python and pip (if not already installed)
apt-get update
apt-get install -y python3 python3-pip

# Copy the panel files to your server
# Upload dst-panel-backend.py, requirements.txt, and the static/ folder

# Install dependencies
pip3 install -r requirements.txt --break-system-packages

# Run the server
python3 dst-panel-backend.py
```

### Access the Panel

Open your browser to: `http://YOUR_SERVER_IP:5555`

## Security Notes

**WARNING**: This panel has NO AUTHENTICATION. Anyone who can access port 5555 can control your server!

For production use, you should:
1. Set up a reverse proxy with authentication (nginx + basic auth)
2. Use HTTPS
3. Restrict access to trusted IPs only
4. Consider adding user authentication to the Flask app

## File Structure

```
dst-server-panel/
├── dst-panel-backend.py    # Python Flask backend
├── requirements.txt        # Python dependencies
├── static/
│   ├── index.html         # Main UI
│   ├── style.css          # Dark theme styling
│   └── app.js             # Frontend JavaScript
└── README.md              # This file
```

## Usage

### Command Console
- Type Lua commands directly
- Use quick command buttons
- View command history in output

### Player Management
1. Select a player from dropdown
2. Click action button
3. Confirm if prompted

### Config Editor
1. Select file from dropdown
2. Edit in textarea
3. Click "SAVE CHANGES"
4. Original file is backed up automatically

### Backups
1. Enter optional backup name
2. Click "CREATE BACKUP"
3. Backups saved to cluster/backups/
4. Restore stops server, replaces saves, restarts

## Theming

Uses a professional dark theme inspired by:
- GitHub Dark
- VSCode Dark+
- Terminal aesthetics
- IBM Plex Mono font

Colors:
- Primary: #0a0e14 (dark blue-black)
- Accent: #58a6ff (GitHub blue)
- Success: #3fb950 (green)
- Warning: #d29922 (orange)
- Danger: #f85149 (red)

## API Endpoints

### GET /api/status
Returns server status, players, game state

### POST /api/command
Execute Lua command
```json
{
  "command": "c_godmode()",
  "shard": "master"
}
```

### POST /api/server/restart
Restart both server shards

### GET /api/logs/{shard}?type=server|chat
Get log file content

### GET /api/config/{file_path}
Read config file

### POST /api/config/{file_path}
Save config file
```json
{
  "content": "file content here"
}
```

### POST /api/mods
Manage mods
```json
{
  "mod_id": "2189004162",
  "action": "toggle|add",
  "enabled": true
}
```

### POST /api/backup
Create backup
```json
{
  "name": "optional-name"
}
```

### GET /api/backups
List all backups

### POST /api/backup/restore
Restore from backup
```json
{
  "name": "backup_20250209_123456"
}
```

### POST /api/player/{action}
Player actions: kick, ban, admin, heal, godmode, kill, resurrect
```json
{
  "player": "PlayerName"
}
```

## Troubleshooting

### Panel won't start
- Check Python is installed: `python3 --version`
- Check dependencies: `pip3 list | grep -i flask`
- Check port 5555 is available: `netstat -tlnp | grep 5555`

### Can't connect to panel
- Check firewall allows port 5555
- Verify panel is running: `ps aux | grep dst-panel`
- Check you're using correct IP address

### Commands not working
- Verify screen sessions are running: `screen -ls`
- Check server logs for errors
- Ensure you're sending valid Lua commands

### Config changes not saving
- Check file permissions
- Verify cluster path is correct
- Look for errors in Python console

## License

MIT License - Use freely, modify as needed
