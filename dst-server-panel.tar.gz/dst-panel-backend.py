#!/usr/bin/env python3
import os
import subprocess
import json
import re
from datetime import datetime
from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
import threading
import time

app = Flask(__name__, static_folder='static')
CORS(app)

# Configuration
DST_BASE = os.path.expanduser("~/.klei/DoNotStarveTogether")
CLUSTER_NAME = "The Hollowed Hunger"
CLUSTER_PATH = os.path.join(DST_BASE, CLUSTER_NAME)
DST_INSTALL = os.path.expanduser("~/DST")

class DSTServerManager:
    def __init__(self):
        self.server_stats = {
            'master_online': False,
            'caves_online': False,
            'players': [],
            'uptime': 0,
            'game_day': 0,
            'season': 'Unknown'
        }
        self.start_monitoring()
    
    def start_monitoring(self):
        """Start background monitoring thread"""
        def monitor():
            while True:
                self.update_server_status()
                time.sleep(5)
        
        thread = threading.Thread(target=monitor, daemon=True)
        thread.start()
    
    def update_server_status(self):
        """Update server status from screen sessions and logs"""
        try:
            # Check if screen sessions are running
            result = subprocess.run(['screen', '-ls'], capture_output=True, text=True)
            self.server_stats['master_online'] = 'dst_master' in result.stdout
            self.server_stats['caves_online'] = 'dst_caves' in result.stdout
            
            # Parse Master log for player info and game state
            master_log = os.path.join(CLUSTER_PATH, 'Master', 'server_log.txt')
            if os.path.exists(master_log):
                self.parse_log_file(master_log)
            
        except Exception as e:
            print(f"Error updating status: {e}")
    
    def parse_log_file(self, log_path):
        """Parse log file for game state and player info"""
        try:
            with open(log_path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
                
            # Get last 100 lines for performance
            recent_lines = lines[-100:]
            
            # Extract players
            players = []
            for line in reversed(recent_lines):
                if 'Client authenticated:' in line:
                    match = re.search(r'Client authenticated: \((\w+)\) (.+)', line)
                    if match:
                        player_id = match.group(1)
                        player_name = match.group(2)
                        if not any(p['name'] == player_name for p in players):
                            players.append({
                                'id': player_id,
                                'name': player_name,
                                'connected': True
                            })
            
            self.server_stats['players'] = players
            
            # Extract game day
            for line in reversed(recent_lines):
                if 'Day' in line:
                    day_match = re.search(r'Day (\d+)', line)
                    if day_match:
                        self.server_stats['game_day'] = int(day_match.group(1))
                        break
            
        except Exception as e:
            print(f"Error parsing log: {e}")
    
    def execute_command(self, command, shard='master'):
        """Execute a Lua command in the server console"""
        try:
            screen_name = f'dst_{shard}'
            # Send command to screen session
            cmd = ['screen', '-S', screen_name, '-X', 'stuff', f'{command}\n']
            result = subprocess.run(cmd, capture_output=True, text=True)
            return {'success': result.returncode == 0, 'output': result.stdout}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def restart_server(self):
        """Restart both server shards"""
        try:
            # Stop servers
            subprocess.run(['screen', '-S', 'dst_master', '-X', 'quit'], stderr=subprocess.DEVNULL)
            subprocess.run(['screen', '-S', 'dst_caves', '-X', 'quit'], stderr=subprocess.DEVNULL)
            time.sleep(3)
            
            # Start servers
            start_script = os.path.join(DST_INSTALL, 'start_dst.sh')
            subprocess.Popen(['bash', start_script], cwd=DST_INSTALL)
            return {'success': True}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def get_log_content(self, shard='master', log_type='server'):
        """Get log file content"""
        try:
            log_files = {
                'server': 'server_log.txt',
                'chat': 'server_chat_log.txt'
            }
            
            shard_path = os.path.join(CLUSTER_PATH, shard.capitalize())
            log_file = os.path.join(shard_path, log_files.get(log_type, 'server_log.txt'))
            
            if not os.path.exists(log_file):
                return {'success': False, 'error': 'Log file not found'}
            
            with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
                # Get last 500 lines
                content = ''.join(lines[-500:])
            
            return {'success': True, 'content': content}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def read_config_file(self, file_path):
        """Read a configuration file"""
        try:
            full_path = os.path.join(CLUSTER_PATH, file_path)
            if not os.path.exists(full_path):
                return {'success': False, 'error': 'File not found'}
            
            with open(full_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            return {'success': True, 'content': content}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def write_config_file(self, file_path, content):
        """Write to a configuration file"""
        try:
            full_path = os.path.join(CLUSTER_PATH, file_path)
            
            # Backup original
            if os.path.exists(full_path):
                backup_path = f"{full_path}.backup.{int(time.time())}"
                with open(full_path, 'r') as f:
                    backup_content = f.read()
                with open(backup_path, 'w') as f:
                    f.write(backup_content)
            
            # Write new content
            with open(full_path, 'w', encoding='utf-8') as f:
                f.write(content)
            
            return {'success': True}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def manage_mod(self, mod_id, action='toggle', enabled=True):
        """Manage mod configuration"""
        try:
            for shard in ['Master', 'Caves']:
                modoverrides_path = os.path.join(CLUSTER_PATH, shard, 'modoverrides.lua')
                
                if not os.path.exists(modoverrides_path):
                    continue
                
                with open(modoverrides_path, 'r') as f:
                    content = f.read()
                
                if action == 'toggle':
                    # Toggle mod enabled state
                    pattern = f'\\["workshop-{mod_id}"\\] = \\{{ enabled = (true|false) \\}}'
                    new_state = 'true' if enabled else 'false'
                    content = re.sub(pattern, f'["workshop-{mod_id}"] = {{ enabled = {new_state} }}', content)
                elif action == 'add':
                    # Add new mod
                    if f'workshop-{mod_id}' not in content:
                        # Insert before closing brace
                        insert_line = f'  ["workshop-{mod_id}"] = {{ enabled = true }},\n'
                        content = content.replace('}', f'{insert_line}}}')
                
                with open(modoverrides_path, 'w') as f:
                    f.write(content)
            
            return {'success': True}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def create_backup(self, backup_name=None):
        """Create a backup of the current world"""
        try:
            if not backup_name:
                backup_name = f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            
            backup_dir = os.path.join(CLUSTER_PATH, 'backups', backup_name)
            os.makedirs(backup_dir, exist_ok=True)
            
            # Backup Master and Caves save directories
            for shard in ['Master', 'Caves']:
                save_dir = os.path.join(CLUSTER_PATH, shard, 'save')
                if os.path.exists(save_dir):
                    backup_shard = os.path.join(backup_dir, shard)
                    subprocess.run(['cp', '-r', save_dir, backup_shard], check=True)
            
            return {'success': True, 'backup_name': backup_name}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def list_backups(self):
        """List all available backups"""
        try:
            backup_dir = os.path.join(CLUSTER_PATH, 'backups')
            if not os.path.exists(backup_dir):
                return {'success': True, 'backups': []}
            
            backups = []
            for name in os.listdir(backup_dir):
                backup_path = os.path.join(backup_dir, name)
                if os.path.isdir(backup_path):
                    stat = os.stat(backup_path)
                    backups.append({
                        'name': name,
                        'created': datetime.fromtimestamp(stat.st_ctime).isoformat(),
                        'size': self.get_dir_size(backup_path)
                    })
            
            backups.sort(key=lambda x: x['created'], reverse=True)
            return {'success': True, 'backups': backups}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def get_dir_size(self, path):
        """Calculate directory size"""
        total = 0
        for dirpath, dirnames, filenames in os.walk(path):
            for f in filenames:
                fp = os.path.join(dirpath, f)
                if os.path.exists(fp):
                    total += os.path.getsize(fp)
        return total
    
    def restore_backup(self, backup_name):
        """Restore from a backup"""
        try:
            backup_dir = os.path.join(CLUSTER_PATH, 'backups', backup_name)
            if not os.path.exists(backup_dir):
                return {'success': False, 'error': 'Backup not found'}
            
            # Stop servers first
            subprocess.run(['screen', '-S', 'dst_master', '-X', 'quit'], stderr=subprocess.DEVNULL)
            subprocess.run(['screen', '-S', 'dst_caves', '-X', 'quit'], stderr=subprocess.DEVNULL)
            time.sleep(2)
            
            # Restore Master and Caves
            for shard in ['Master', 'Caves']:
                backup_shard = os.path.join(backup_dir, shard)
                if os.path.exists(backup_shard):
                    save_dir = os.path.join(CLUSTER_PATH, shard, 'save')
                    # Remove old save
                    if os.path.exists(save_dir):
                        subprocess.run(['rm', '-rf', save_dir], check=True)
                    # Copy backup
                    subprocess.run(['cp', '-r', backup_shard, save_dir], check=True)
            
            # Restart servers
            start_script = os.path.join(DST_INSTALL, 'start_dst.sh')
            subprocess.Popen(['bash', start_script], cwd=DST_INSTALL)
            
            return {'success': True}
        except Exception as e:
            return {'success': False, 'error': str(e)}

# Initialize manager
manager = DSTServerManager()

# API Routes
@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/api/status')
def get_status():
    return jsonify(manager.server_stats)

@app.route('/api/command', methods=['POST'])
def execute_command():
    data = request.json
    command = data.get('command')
    shard = data.get('shard', 'master')
    
    if not command:
        return jsonify({'success': False, 'error': 'No command provided'}), 400
    
    result = manager.execute_command(command, shard)
    return jsonify(result)

@app.route('/api/server/restart', methods=['POST'])
def restart_server():
    result = manager.restart_server()
    return jsonify(result)

@app.route('/api/logs/<shard>')
def get_logs(shard):
    log_type = request.args.get('type', 'server')
    result = manager.get_log_content(shard, log_type)
    return jsonify(result)

@app.route('/api/config/<path:file_path>')
def get_config(file_path):
    result = manager.read_config_file(file_path)
    return jsonify(result)

@app.route('/api/config/<path:file_path>', methods=['POST'])
def save_config(file_path):
    content = request.json.get('content')
    if content is None:
        return jsonify({'success': False, 'error': 'No content provided'}), 400
    
    result = manager.write_config_file(file_path, content)
    return jsonify(result)

@app.route('/api/mods', methods=['POST'])
def manage_mods():
    data = request.json
    mod_id = data.get('mod_id')
    action = data.get('action', 'toggle')
    enabled = data.get('enabled', True)
    
    result = manager.manage_mod(mod_id, action, enabled)
    return jsonify(result)

@app.route('/api/backup', methods=['POST'])
def create_backup():
    backup_name = request.json.get('name')
    result = manager.create_backup(backup_name)
    return jsonify(result)

@app.route('/api/backups')
def list_backups():
    result = manager.list_backups()
    return jsonify(result)

@app.route('/api/backup/restore', methods=['POST'])
def restore_backup():
    backup_name = request.json.get('name')
    if not backup_name:
        return jsonify({'success': False, 'error': 'No backup name provided'}), 400
    
    result = manager.restore_backup(backup_name)
    return jsonify(result)

@app.route('/api/player/<action>', methods=['POST'])
def player_action(action):
    data = request.json
    player_name = data.get('player')
    
    actions = {
        'kick': f'TheNet:Kick("{player_name}")',
        'ban': f'TheNet:Ban("{player_name}")',
        'admin': f'c_select(TheNet:GetClientTable()[1]) c_setrole("admin")',
        'heal': f'for k,v in pairs(AllPlayers) do if v:GetDisplayName()=="{player_name}" then v.components.health:SetPercent(1) end end',
        'godmode': f'for k,v in pairs(AllPlayers) do if v:GetDisplayName()=="{player_name}" then v.components.health:SetInvincible(true) end end',
        'kill': f'for k,v in pairs(AllPlayers) do if v:GetDisplayName()=="{player_name}" then v.components.health:Kill() end end',
        'resurrect': f'for k,v in pairs(AllPlayers) do if v:GetDisplayName()=="{player_name}" then v:PushEvent("respawnfromghost") end end'
    }
    
    if action not in actions:
        return jsonify({'success': False, 'error': 'Invalid action'}), 400
    
    result = manager.execute_command(actions[action])
    return jsonify(result)

if __name__ == '__main__':
    print("Starting DST Server Panel Backend...")
    print("Access panel at: http://localhost:5555")
    app.run(host='0.0.0.0', port=5555, debug=True)
