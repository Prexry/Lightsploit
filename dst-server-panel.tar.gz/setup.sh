#!/usr/bin/env bash
set -euo pipefail

echo "========================================="
echo "DST Server Control Panel - Setup"
echo "========================================="
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "⚠️  Not running as root. Some operations may require sudo."
    echo ""
fi

# Install Python dependencies
echo "📦 Installing Python dependencies..."
if command -v pip3 &> /dev/null; then
    pip3 install -r requirements.txt --break-system-packages
elif command -v pip &> /dev/null; then
    pip install -r requirements.txt --break-system-packages
else
    echo "❌ Error: pip not found. Please install Python3 and pip3."
    exit 1
fi

echo "✅ Dependencies installed"
echo ""

# Make backend executable
chmod +x dst-panel-backend.py

# Create systemd service (optional)
read -p "Create systemd service for auto-start? (y/n) " -n 1 -r
echo ""
if [[ $REPLY =~ ^[Yy]$ ]]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    
    sudo tee /etc/systemd/system/dst-panel.service > /dev/null <<SERVICE
[Unit]
Description=DST Server Control Panel
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$SCRIPT_DIR
ExecStart=/usr/bin/python3 $SCRIPT_DIR/dst-panel-backend.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
SERVICE
    
    sudo systemctl daemon-reload
    sudo systemctl enable dst-panel.service
    
    echo "✅ Systemd service created"
    echo "   Start with: sudo systemctl start dst-panel"
    echo "   Stop with: sudo systemctl stop dst-panel"
    echo "   View logs: sudo journalctl -u dst-panel -f"
fi

echo ""
echo "========================================="
echo "✅ Setup Complete!"
echo "========================================="
echo ""
echo "To start the panel:"
echo "  python3 dst-panel-backend.py"
echo ""
echo "Then open your browser to:"
echo "  http://localhost:5555"
echo "  or"
echo "  http://YOUR_SERVER_IP:5555"
echo ""
echo "⚠️  WARNING: This panel has NO authentication!"
echo "   Only use on trusted networks or add authentication."
echo ""
