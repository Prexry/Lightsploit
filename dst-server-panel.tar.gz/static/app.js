const API_BASE = '';

// State
let statusInterval;
let currentPage = 'dashboard';

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    startStatusUpdates();
    loadConfigFile();
    loadBackups();
    loadLogs();
    populateModList();
});

// Navigation
function initNavigation() {
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', () => {
            const page = item.dataset.page;
            switchPage(page);
        });
    });
}

function switchPage(page) {
    // Update nav
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    document.querySelector(`[data-page="${page}"]`).classList.add('active');
    
    // Update content
    document.querySelectorAll('.page').forEach(p => {
        p.classList.remove('active');
    });
    document.getElementById(page).classList.add('active');
    
    currentPage = page;
}

// Status Updates
function startStatusUpdates() {
    updateStatus();
    statusInterval = setInterval(updateStatus, 3000);
}

async function updateStatus() {
    try {
        const response = await fetch(`${API_BASE}/api/status`);
        const data = await response.json();
        
        // Update status indicators
        const masterStatus = document.getElementById('master-status');
        const cavesStatus = document.getElementById('caves-status');
        
        if (data.master_online) {
            masterStatus.classList.add('online');
            document.getElementById('master-text').textContent = 'ONLINE';
        } else {
            masterStatus.classList.remove('online');
            document.getElementById('master-text').textContent = 'OFFLINE';
        }
        
        if (data.caves_online) {
            cavesStatus.classList.add('online');
            document.getElementById('caves-text').textContent = 'ONLINE';
        } else {
            cavesStatus.classList.remove('online');
            document.getElementById('caves-text').textContent = 'OFFLINE';
        }
        
        // Update stats
        document.getElementById('player-count').textContent = data.players.length;
        document.getElementById('online-players').textContent = data.players.length;
        document.getElementById('game-day').textContent = data.game_day || 0;
        document.getElementById('season').textContent = data.season || '---';
        
        // Update player list
        updatePlayerList(data.players);
        updatePlayerSelect(data.players);
        
    } catch (error) {
        console.error('Failed to fetch status:', error);
    }
}

function updatePlayerList(players) {
    const container = document.getElementById('player-list');
    
    if (players.length === 0) {
        container.innerHTML = '<div class="empty-state">No players connected</div>';
        return;
    }
    
    container.innerHTML = players.map(player => `
        <div class="player-item">
            <div>
                <div class="player-name">${escapeHtml(player.name)}</div>
                <div class="player-id">${player.id}</div>
            </div>
        </div>
    `).join('');
}

function updatePlayerSelect(players) {
    const select = document.getElementById('player-select');
    
    if (players.length === 0) {
        select.innerHTML = '<option value="">-- No players --</option>';
        return;
    }
    
    select.innerHTML = players.map(player => 
        `<option value="${escapeHtml(player.name)}">${escapeHtml(player.name)} (${player.id})</option>`
    ).join('');
}

// Command Execution
async function sendCommand(command, shard = 'master') {
    try {
        logConsole(`> ${command}`, 'command');
        
        const response = await fetch(`${API_BASE}/api/command`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ command, shard })
        });
        
        const result = await response.json();
        
        if (result.success) {
            logConsole('[OK] Command sent', 'success');
        } else {
            logConsole(`[ERROR] ${result.error}`, 'error');
        }
        
        return result;
    } catch (error) {
        logConsole(`[ERROR] ${error.message}`, 'error');
        return { success: false, error: error.message };
    }
}

function handleCommandInput(event) {
    if (event.key === 'Enter') {
        executeCommand();
    }
}

function executeCommand() {
    const input = document.getElementById('command-input');
    const command = input.value.trim();
    
    if (!command) return;
    
    sendCommand(command);
    input.value = '';
}

function logConsole(message, type = 'info') {
    const output = document.getElementById('console-output');
    const line = document.createElement('div');
    line.className = `console-line ${type}`;
    line.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
    output.appendChild(line);
    output.scrollTop = output.scrollHeight;
}

// Server Control
async function restartServer() {
    if (!confirm('Restart the server? Players will be disconnected.')) return;
    
    logConsole('Restarting server...', 'warning');
    
    try {
        const response = await fetch(`${API_BASE}/api/server/restart`, {
            method: 'POST'
        });
        
        const result = await response.json();
        
        if (result.success) {
            logConsole('Server restart initiated', 'success');
        } else {
            logConsole(`Failed to restart: ${result.error}`, 'error');
        }
    } catch (error) {
        logConsole(`Error: ${error.message}`, 'error');
    }
}

function rollback() {
    if (!confirm('Rollback to previous save?')) return;
    sendCommand('c_rollback(1)');
}

function regenerateWorld() {
    if (!confirm('WARNING: This will DELETE the current world and generate a new one! Are you absolutely sure?')) return;
    if (!confirm('Last chance - this cannot be undone!')) return;
    sendCommand('c_regenerateworld()');
}

// Player Actions
async function playerAction(action) {
    const select = document.getElementById('player-select');
    const player = select.value;
    
    if (!player) {
        alert('Please select a player');
        return;
    }
    
    if ((action === 'ban' || action === 'kill') && !confirm(`${action.toUpperCase()} ${player}?`)) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/api/player/${action}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ player })
        });
        
        const result = await response.json();
        
        if (result.success) {
            logConsole(`${action} executed on ${player}`, 'success');
        } else {
            logConsole(`Failed: ${result.error}`, 'error');
        }
    } catch (error) {
        logConsole(`Error: ${error.message}`, 'error');
    }
}

// Config Management
async function loadConfigFile() {
    const select = document.getElementById('config-file-select');
    const filePath = select.value;
    const editor = document.getElementById('config-editor');
    
    try {
        const response = await fetch(`${API_BASE}/api/config/${filePath}`);
        const result = await response.json();
        
        if (result.success) {
            editor.value = result.content;
        } else {
            editor.value = `Error loading file: ${result.error}`;
        }
    } catch (error) {
        editor.value = `Error: ${error.message}`;
    }
}

async function saveConfigFile() {
    const select = document.getElementById('config-file-select');
    const filePath = select.value;
    const editor = document.getElementById('config-editor');
    const content = editor.value;
    
    if (!confirm(`Save changes to ${filePath}?`)) return;
    
    try {
        const response = await fetch(`${API_BASE}/api/config/${filePath}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ content })
        });
        
        const result = await response.json();
        
        if (result.success) {
            logConsole(`Saved ${filePath}`, 'success');
            alert('Configuration saved successfully');
        } else {
            logConsole(`Failed to save: ${result.error}`, 'error');
            alert(`Error: ${result.error}`);
        }
    } catch (error) {
        logConsole(`Error: ${error.message}`, 'error');
        alert(`Error: ${error.message}`);
    }
}

// Mod Management
function populateModList() {
    const mods = [
        { id: '2189004162', name: 'Insight' },
        { id: '2078243581', name: 'Display Attack Range' },
        { id: '3571706033', name: 'Wormhole Marks' },
        { id: '378160973', name: 'Global Positions' },
        { id: '2528541304', name: 'Too Many Turfs' },
        { id: '1185229307', name: 'Epic Health Bar' },
        { id: '3624411781', name: 'Storage Bags' }
    ];
    
    const container = document.getElementById('mod-list');
    container.innerHTML = mods.map(mod => `
        <div class="mod-item">
            <div>
                <div class="mod-name">${mod.name}</div>
                <div class="mod-id">workshop-${mod.id}</div>
            </div>
            <div class="toggle active" onclick="toggleMod(this, '${mod.id}')"></div>
        </div>
    `).join('');
}

async function toggleMod(element, modId) {
    element.classList.toggle('active');
    const enabled = element.classList.contains('active');
    
    try {
        const response = await fetch(`${API_BASE}/api/mods`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ mod_id: modId, action: 'toggle', enabled })
        });
        
        const result = await response.json();
        
        if (result.success) {
            logConsole(`Mod ${modId} ${enabled ? 'enabled' : 'disabled'}`, 'success');
        } else {
            logConsole(`Failed: ${result.error}`, 'error');
            element.classList.toggle('active'); // Revert
        }
    } catch (error) {
        logConsole(`Error: ${error.message}`, 'error');
        element.classList.toggle('active'); // Revert
    }
}

async function addMod() {
    const input = document.getElementById('new-mod-id');
    const modId = input.value.trim();
    
    if (!modId) {
        alert('Please enter a Workshop ID');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/api/mods`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ mod_id: modId, action: 'add' })
        });
        
        const result = await response.json();
        
        if (result.success) {
            logConsole(`Mod ${modId} added`, 'success');
            alert('Mod added. Restart server to download.');
            input.value = '';
            populateModList(); // Refresh
        } else {
            alert(`Error: ${result.error}`);
        }
    } catch (error) {
        alert(`Error: ${error.message}`);
    }
}

// Backup Management
async function createBackup() {
    const nameInput = document.getElementById('backup-name');
    const name = nameInput.value.trim();
    
    logConsole('Creating backup...', 'info');
    
    try {
        const response = await fetch(`${API_BASE}/api/backup`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name })
        });
        
        const result = await response.json();
        
        if (result.success) {
            logConsole(`Backup created: ${result.backup_name}`, 'success');
            alert('Backup created successfully');
            nameInput.value = '';
            loadBackups();
        } else {
            logConsole(`Failed: ${result.error}`, 'error');
            alert(`Error: ${result.error}`);
        }
    } catch (error) {
        logConsole(`Error: ${error.message}`, 'error');
        alert(`Error: ${error.message}`);
    }
}

async function loadBackups() {
    try {
        const response = await fetch(`${API_BASE}/api/backups`);
        const result = await response.json();
        
        const container = document.getElementById('backup-list');
        
        if (!result.success || result.backups.length === 0) {
            container.innerHTML = '<div class="empty-state">No backups found</div>';
            return;
        }
        
        container.innerHTML = result.backups.map(backup => `
            <div class="backup-item">
                <div class="backup-header">
                    <div class="backup-name">${escapeHtml(backup.name)}</div>
                </div>
                <div class="backup-meta">
                    Created: ${new Date(backup.created).toLocaleString()}<br>
                    Size: ${formatBytes(backup.size)}
                </div>
                <div class="backup-actions">
                    <button class="btn warning" onclick="restoreBackup('${escapeHtml(backup.name)}')">RESTORE</button>
                    <button class="btn danger" onclick="deleteBackup('${escapeHtml(backup.name)}')">DELETE</button>
                </div>
            </div>
        `).join('');
    } catch (error) {
        console.error('Failed to load backups:', error);
    }
}

async function restoreBackup(name) {
    if (!confirm(`Restore backup "${name}"? This will OVERWRITE the current world!`)) return;
    if (!confirm('Are you absolutely sure? This cannot be undone!')) return;
    
    logConsole(`Restoring backup: ${name}`, 'warning');
    
    try {
        const response = await fetch(`${API_BASE}/api/backup/restore`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name })
        });
        
        const result = await response.json();
        
        if (result.success) {
            logConsole('Backup restored successfully', 'success');
            alert('Backup restored. Server is restarting...');
        } else {
            logConsole(`Failed: ${result.error}`, 'error');
            alert(`Error: ${result.error}`);
        }
    } catch (error) {
        logConsole(`Error: ${error.message}`, 'error');
        alert(`Error: ${error.message}`);
    }
}

// Logs
async function loadLogs() {
    const select = document.getElementById('log-select');
    const [shard, type] = select.value.split('-');
    const viewer = document.getElementById('log-content');
    
    viewer.textContent = 'Loading...';
    
    try {
        const response = await fetch(`${API_BASE}/api/logs/${shard}?type=${type}`);
        const result = await response.json();
        
        if (result.success) {
            viewer.textContent = result.content;
        } else {
            viewer.textContent = `Error: ${result.error}`;
        }
    } catch (error) {
        viewer.textContent = `Error: ${error.message}`;
    }
}

// Utilities
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

function formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}
